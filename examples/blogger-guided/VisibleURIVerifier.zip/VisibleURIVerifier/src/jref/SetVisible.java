package jref;

import com.jreframeworker.annotations.methods.DefineMethodVisibility;

@DefineMethodVisibility(phase=1, type="fi.iki.elonen.URIVerifier", method = "URIVerifier", visibility="public")

public class SetVisible {

}
